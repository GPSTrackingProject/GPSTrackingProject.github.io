$now = getdate(); 
    $currentTime = $now["hours"] . ":" . $now["minutes"] . ":" . $now["seconds"]; 
    $currentDate = $now["mday"] . "." . $now["mon"] . "." . $now["year"]; 
    $currentWeek = $now["wday"] . ".";  