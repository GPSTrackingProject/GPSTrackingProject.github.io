<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Đăng ký - GPSTracking</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript" src="script.js"></script>
</body>
</html>
<?php
	require_once("mysql.php");
	if (!isset($_POST['user']) || !isset($_POST['pass']) || !isset($_POST['email']))
	{
		echo '<h3>'."Điền đầy đủ thông tin!";
	}
	else
	if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['email']))
	{
	$user=addslashes(mysql_real_escape_string($_POST['user']));
	$pass=md5(sha1(md5($_POST['pass'])));
	$email=addslashes(mysql_real_escape_string($_POST['email']));
		$sql=mysql_query("select * from user where user='$user'");
		if (mysql_num_rows($sql)<=0)
		{
			$sql=mysql_query("insert into user (user,pass,email) values('$user','$pass','$email')");
			if (@$sql)
			{
				echo '<h3>'."Thêm thành công!";	
				header ("Location: login_form.php");
			}
			else echo '<h3>'."Có lỗi trong quá trình thực hiện!";
		}		
		else echo '<h3>'.'User đã tồn tại!';
	}
	else echo '<h3>'."Điền đầy đủ thông tin!";
?>