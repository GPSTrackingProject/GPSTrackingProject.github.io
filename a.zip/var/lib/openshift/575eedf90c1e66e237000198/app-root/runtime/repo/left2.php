<div class="col-md-3">
                <p class="lead">GPS Tracking</p>
                <div class="list-group">
                <a href="#" class="list-group-item">Quá trình đi 
<div>
<select name="quatrinh" id="optionchonxe">
<option selected="selected" value="0">Chọn xe</option>
<?php
	$row =array();
	$sql= mysql_query("select * from imei where user_id = '$user_id'");
	while ($rowimei=mysql_fetch_array($sql))
	{
		$imei = $rowimei['id'];
		$bangsoxe = $rowimei['bangsoxe'];
		echo '<option value="'.$imei.'&bangsoxe='.$bangsoxe.'">'.$bangsoxe.'</option>';
		array_push($row,$rowimei);
	}
?>
</select>
<button id='btnxem'onclick="btnxemclick()">Xem</button>
</div></a>
                    <a href="thongtincanhan.php" class="list-group-item">Thông tin cá nhân</a>
                </div>
<div>
	
	<form action='quatrinh.php' method="GET">
	<input type="hidden" name="bangsoxe" value="<?php echo $bangsoxe;?>"/>
	<input type="hidden" name="imei" value="<?php echo $id_imei;?>"/>
	<input type="text" name="date" class="tcal" value="<?php echo $date;?>" />
	<input type="submit" value="GO!"/>
	</form>
	<button id='btnxemlai'onclick="btnxemlaiclick()">Xem lại</button>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
<table style="width:100%">
  <tr>
    <th>Thời gian</th>
    <th>Tốc độ</th>
    <th>Vị trí</th>
  </tr>
<?php
	$i=0;
	$sql=mysql_query("select * from tracking where id_imei=$id_imei and date='$date'");
	while ($rowtracking=mysql_fetch_array($sql))
	{
		$i++;
		if ($i%2==1)
		{
                $thoigian = $rowtracking['time'];
		$des = $rowtracking['vitri'];
		$speed = $rowtracking['tocdo'];
		if (($thoigian!='') or ($des!='') or ($speed!=0)) 
	         echo '<tr><th>'.$thoigian.'</th><th>'.$speed.'</th><th>'.$des.'</th></tr>';
		}
	}
?>
</table>
</div>
</div>
