<?php
session_start();
require_once('mysql.php');
if (!isset($_POST['user'])||!isset($_POST['pass']))
	echo '<br>'.'Điền đầy đủ thông tin!';
else
if (isset($_POST['user'])&&isset($_POST['pass']))	
{
	$user =addslashes(mysql_real_escape_string($_POST['user']));
	$pass =md5(sha1(md5($_POST['pass'])));
	$sql = mysql_query("select * from user where user = '$user'");
	if (mysql_num_rows($sql)>0)//KIểm tra user có tồn tại không
	{
		$admin = @mysql_fetch_array($sql);
		if ($admin['pass'] == $pass)//Kiểm tra pass có đúng không
		{
			echo'<br>'.'Xin chào';
			$_SESSION['user_id']= $admin['id'];
			echo $_SESSION['user_id'];
			header("Location: index.php");
		}
		else echo '<br>'.'Sai password';
	}
	else echo '<br>'."Không tồn tại";
}
?>