<?php
session_start();
require_once('mysql.php');
if(!isset($_SESSION['user_id']))
{
header("Location:login_form.php");
}
$user_id=$_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>GPS Tracking-Nhà thiếu nhi Đồng Nai</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-item.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
<?php include('menu.php');?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">
                <div class="thumbnail">
                    <!-- đánh dâu-->
					 <?php
					 $sql_2= mysql_query("select * from imei where user_id='$user_id'");
					 $sql_3= mysql_query("select * from user where id='$user_id'");
					 $imei='';
					 $user='';
					/*!while ($rowuser=mysql_fetch_array($sql_3))
					{
					$user = $rowuser['user'];
					$email = $rowuser['email'];
					echo $user;
					echo $email;
					}*/
                    while ($rowuser=mysql_fetch_array($sql_3))
					{
					$user = $rowuser['user'];
					$email = $rowuser['email'];
					echo 'Tài khoản: ';
					echo $user;echo '<br>';
					echo 'Email:  ';
					echo $email;
					}
                                        echo '<br>';
					echo 'Các số imei và bảng số xe đã đăng kí: <br>';
					while ($rowimei=mysql_fetch_array($sql_2))
					{
					$imei = $rowimei['so_imei'];
					$bangsoxe = $rowimei['bangsoxe'];
					echo '- Số imei: ';
					echo $imei;echo '<br>';
					echo '-  Bảng số xe: ';
					echo $bangsoxe;
					echo '<br>';
					}
					 ?>

 </div>
		</div>

        </div
</div
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; GPS Tracking by Nhà thiếu nhi Đồng Nai</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
